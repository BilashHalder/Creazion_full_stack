import React from 'react'
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
export default function UserForgetPass() {
  return (
    <Box
    component="form"
    sx={{
      '& > :not(style)': { m: 1, width: '50ch' },
    }}  noValidate autoComplete="off"
  >
    <TextField id="outlined-basic" label="Email Id or Phone No" variant="outlined" type={"password"}/>
     <Button variant="outlined" size="large" type="submit">Reset Password</Button>
  </Box>
  )
}
