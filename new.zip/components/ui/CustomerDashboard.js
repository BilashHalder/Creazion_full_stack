import React from 'react'
import InfoCard from './InfoCard'
import Sample from '../chart/Sample'
export default function CustomerDashboard() {
  return (
    <div className='container-fluid row'>
      <h3>Hi,User Good Afternnon</h3>
       <div className='col-md-5'>
       <img src="/images/dashboard.png" alt="" style={{width:"100%"}}/>
       </div>
       <div className='col-md-7 ps-5 mt-4'>
       <div class="row mt-2">
        <InfoCard title="Invesment" content="1299"/>
        <InfoCard title="Profit" content="1299"/>
        <InfoCard title="Balance" content="1299"/>
        <InfoCard title="Today Profit" content="1299"/>
  </div>
       </div>
<Sample/>
    </div>
  )
}
