import React from 'react'

export default function InfoCard(props) {
  return (
    <div class="col-md-6 p-3">
      <div class="card " style={{backgroundImage:"url('/images/wallet_bg.png')"}}>
        <h3>{props.title}</h3>
        <p>{props.content}</p>
      </div>
    </div>
  )
}
