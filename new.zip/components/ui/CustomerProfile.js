import React from 'react'

export default function CustomerProfile() {
  return (
    <div>CustomerProfile</div>
  )
}
