import React from 'react'

export default function CustomerInvesments() {
  return (
    <div>CustomerInvesments</div>
  )
}
