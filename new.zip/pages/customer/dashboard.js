import React from 'react'
import CustomerMenu from '../../components/menu/CustomerMenu'
export default function dashboard() {
  return (
    <div>
        <CustomerMenu></CustomerMenu>
    </div>
  )
}
