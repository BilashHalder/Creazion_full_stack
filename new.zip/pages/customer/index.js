import React from 'react'
import Login from '../../components/forms/Login';
import ForgetPass from '../../components/forms/ForgetPass';
export default function index() {
  return (
    <div className="container-fluid mt-3 text-center">
      <img src="./images/logo.png" alt="" style={{ height: '100px' }} />
      <h1>Well Come to Creazion Group</h1>

      <div className="row">
        <div className="col-md-6 ">
          <img src="./images/login.png" alt="" style={{ width: '80%' }} />
        </div>

        <div className="col-md-6 ">
        <Login usertype="" />
        </div>
      </div>
    </div>
  )
}
