import React from 'react'
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';

export default function Login() {
  return (
    <>
    <h2 className="">Sign In</h2>
      <hr className="shine"></hr>
    <Box
    component="form"
    sx={{
      '& > :not(style)': { m: 1, width: '50ch' },
    }}
    noValidate
    autoComplete="off"
  >
    <TextField id="outlined-basic" label="Email Id/ Phone No" variant="outlined" type={"text"}/>
    <TextField id="outlined-basic" label="Password" variant="outlined" type={"password"}/>
    <Button variant="outlined" size="large">Sign In</Button>
    <Button href="#text-buttons" size="small">Forget Password ?</Button>
  </Box>
    </>
  )
}
