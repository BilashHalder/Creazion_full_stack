import React from 'react'
import CustomerMenu from '../../components/CustomerMenu'
export default function Dashboard() {
  return (
    <div><CustomerMenu/>
    Dashboard</div>
  )
}
