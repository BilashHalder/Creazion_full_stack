import React from 'react'
import { useState } from 'react';
import Image from 'next/image'
import Grid from '@mui/material/Grid'
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';

import Dashboard from './dashboard';
const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));
export default function index() {
  const [menu,setMenu]=useState(0);
  const [token,setToken]=useState(null);
  const loginShow=()=>{
    setMenu(0)
  }
  const forgetShow=()=>{
    setMenu(1)
  }
  const showDashboard=()=>{
    setToken("mytocken")
  }
  return (
    <>
{token!=null?<Dashboard/>: <div className="container-fluid mt-3 text-center">
    
    <img src="./images/logo.png" alt="" style={{height:'100px'}}/>
     <h1>Well Come to Creazion Group</h1>
    
 <div className="row">
   <div className="col-md-6 ">
     <img src="./images/login.png" alt="" style={{width:'80%'}}/>
   </div>
   {
     menu==0?<div className="col-md-6 text-center mt-4">
     <h2 className="">Sign In</h2>
     <hr className="shine"></hr>
     
     
     <Box
     component="form"
     sx={{
       '& > :not(style)': { m: 1, width: '50ch' },
     }}
     noValidate
     autoComplete="off"
   >
     <TextField id="outlined-basic" label="Email Id/ Phone No" variant="outlined" type={"text"}/>
     <TextField id="outlined-basic" label="Password" variant="outlined" type={"password"}/>
     <Button variant="outlined" size="large" onClick={showDashboard}>Sign In</Button>
     
   </Box>
   <Button onClick={forgetShow} size="small">Forget Password ?</Button>

   </div>: <div className='col-md-6 text-center mt-4'>
   <h2 className="">Forget Password</h2>
     <hr className="shine"></hr>
     <Box
     component="form"
     sx={{
       '& > :not(style)': { m: 1, width: '50ch' },
     }}
     noValidate
     autoComplete="off"
   >
     <TextField id="outlined-basic" label="Email Id or Phone No" variant="outlined" type={"text"}/>
     <Button variant="outlined" size="large" type="submit">Reset Password</Button>
     </Box>
     <Button onClick={loginShow} size="small">Login</Button>
   </div>
   }
   

  

 </div>
 </div>}
   

    </>
  )
}
