const {add,update,find,findbyid,remove}=require("./services");

//	id	full_name	phone_no	email	commission_rate	agreement_id	
//referred_by	image	pass	created_at	status


module.exports={}
